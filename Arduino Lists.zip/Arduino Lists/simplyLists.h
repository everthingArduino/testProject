//  addToMultiList(page, value);
//  replaceInMultiList(page, slot, value);
//  getFromMultiList(page, slot);

//  addToMainList(value);
//  replaceInMainList(slot, value);
//  getFromMainList(slot);





// Multi list
const int multi_list_pages = 3;
const int multi_list_items = 5;

int multi_list[multi_list_pages][multi_list_items] = {
  {0, 0, 0},
  {1, 2, 3}
};
int last_page_item[] = {
  3,
  3
};
const int every_page = -1;
int gotFromMultiList = 0;

// Main List
int main_list[30] = {
  1, 2, 3, 4
};

int last_item = 4;
int gotFromMainList = 0;


void printMultiList() {
  Serial.println("List: ");
  for (int page_counter = 0; page_counter < multi_list_pages; page_counter++) {
    for (int slot_counter = 0; slot_counter < last_page_item[page_counter]; slot_counter++) {
      Serial.print(multi_list[page_counter][slot_counter]);
      if (slot_counter != (last_page_item[page_counter] - 1)) Serial.print(", ");
      else Serial.println();
    }
  }
  Serial.println(); Serial.println();
}
void addToMultiList(int page, int value) {
  multi_list[page][last_page_item[page]] = value;
  Serial.print("Added value[" + String(value) + "] ");
  Serial.print("on page[" + String(page) + "] ");
  Serial.print("to slot[" + String(last_page_item[page]) + "] succesful");
  Serial.println();
  Serial.print("Set last_item for page [" + String(page) + "] ");
  Serial.print("from (" + String(last_page_item[page]) + ") ");
  last_page_item[page] = last_page_item[page] + 1;
  Serial.print("to (" + String(last_page_item[page]) + ") succesful");
  Serial.println(); Serial.println();
}
void replaceInMultiList(int page, int slot, int new_value) {
  Serial.print("Changed value[" + String(multi_list[page][slot]) + "] ");
  Serial.print("on page[" + String(page) + "] ");
  Serial.print("in slot[" + String(slot) + "] ");
  multi_list[page][slot] = new_value;
  Serial.print("to new_value[" + String(new_value) + "] succesful");
  Serial.println(); Serial.println();
}
void getFromMultiList(int page, int slot) {
  gotFromMultiList = multi_list[page][slot];
  Serial.print("Stored value[" + String(gotFromMultiList) + "] ");
  Serial.print("from slot[" + String(slot) + "] ");
  Serial.print("on page[" + String(page) + "] ");
  Serial.print("in <gotFromMultiList>");
  Serial.println(); Serial.println();
}


void printMainList() {
  Serial.println("List: ");
  for (int slot_counter = 0; slot_counter < last_item; slot_counter++) {
    Serial.print(main_list[slot_counter]);
    if (slot_counter != (last_item - 1)) Serial.print(", ");
  }
  Serial.println(); Serial.println();
}
void addToMainList(int value) {
  main_list[last_item] = value;
  Serial.print("Added value[" + String(value) + "] ");
  Serial.print("to slot[" + String(last_item) + "] succesful");
  Serial.println();
  Serial.print("Set last_item from (" + String(last_item) + ") ");
  last_item = last_item + 1;
  Serial.print("to (" + String(last_item) + ") succesful"); 
  Serial.println(); Serial.println();
}
void replaceInMainList(int slot, int new_value) {
  Serial.print("Changed value[" + String(main_list[slot]) + "] ");
  Serial.print("in slot[" + String(slot) + "] ");
  main_list[slot] = new_value;
  Serial.print("to new_value[" + String(new_value) + "] succesful");
  Serial.println(); Serial.println();
}
void getFromMainList(int slot) {
  gotFromMainList = main_list[slot];
  Serial.print("Stored value[" + String(gotFromMainList) + "] ");
  Serial.print("from slot[" + String(slot) + "] ");
  Serial.print("in <gotFromMainList>");
  Serial.println(); Serial.println();
}
